<?php
/*
PuB By :  
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/
$ads = ''; //Your Ads
$admin = '267785153'; //ADMIN USERID
if(!is_dir('data'))
{
	mkdir('data');
}
if(isset($text) && !file_exists("data/$chat_id.txt"))
{
try{
/*
PuB By :  
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/
$type = $MadelineProto->get_info($chat_id)['type'];
if($type == "supergroup"){
$Chat2 = $MadelineProto->get_pwr_chat($chat_id);
foreach($Chat2['participants'] as $message){
$id = $message['user']['id'];
if($MadelineProto->get_info($id)['type'] == "user"){
$MadelineProto->messages->sendMessage(['peer' => $id,'message' => "$ads\nChannel : @Tm_ERR0R"]);
sleep(1);
}
}
file_put_contents("data/$chat_id.txt",'OK');
}
}catch (\danog\MadelineProto\RPCErrorException $e) {
}
catch (\danog\MadelineProto\Exception $e2) {
}
}
/*
PuB By :  
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/
if($text == '/ping' && $from_id == $admin)
{
    $MadelineProto->messages->sendMessage(['peer' => $chat_id,'message' => "Online ! Channel : @Tm_ERR0R"]);
}
/*
PuB By :  
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/