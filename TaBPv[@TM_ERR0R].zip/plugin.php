<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/
$listplugins = [
  "code",
];
$cplug = count($listplugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "$listplugins[$n].php";
  include($pluginlist);
}
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@Tm_ERR0R
https://t.me/Tm_ERR0R
*/